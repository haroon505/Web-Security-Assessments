# CSRF account management assessment

Prepared by Haroon Shahid | CSRF-2026-01 | Revision 1.1

## Files

- CSRF_Account_Management_Assessment.pdf: seven-page assessment with the revised presentation design.
- Assessment_Editable.txt: editable text extracted from the report; figures are supplied separately.
- evidence/: 11 sanitized response excerpts from the supplied screenshots.
- evidence_manifest.json: original screenshot numbers, SHA-256 hashes and excerpt treatment.

## Evidence index

| File | Observation | Report page |
| --- | --- | --- |
| E04.png | Valid-token email baseline | 4 |
| E09.png | Cross-account token rejected; both tokens confirmed valid by the assessor | 4 |
| E10.png | First request before reload accepted | 5 |
| E11.png | Same token reused before reload accepted | 5 |
| E12.png | Old token after reload rejected | 5 |
| E14.png | Replacement token accepted | 5 |
| E16.png | Password-change success response | 6 |
| E17.png | Incorrect current password rejected | 6 |
| E05.png | Missing CSRF token rejected | 7 |
| E06.png | Arbitrary CSRF token rejected | 7 |
| E18.png | Tested GET request rejected | 7 |

## Evidence treatment

The PNGs contain original response excerpts: status/server/date and response body. Intervening headers and request panes are omitted. Request summaries in the PDF are labeled transcriptions with secrets replaced by aliases. No synthetic screenshot text is added. Both cross-account tokens were valid at the time of testing, as confirmed by the assessor.

Original screenshots and the source conversation are excluded because they contain target identifiers and credentials. The report is an anonymized assessment of the documented tests. Its conclusion is: no CSRF vulnerability identified in the tested scenarios.
